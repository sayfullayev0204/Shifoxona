from django import views
from django.urls import path,include
from .views import BemorDetailView,BemorListView


urlpatterns = [


path('',BemorListView.as_view(), name='bemor_list'),
path('bemor/<int:pk>/', BemorDetailView.as_view(), name='bemor_detail'),

]