from django.db import models

# Create your models here.
class bemor(models.Model):
    ismi = models.CharField(max_length=200)
    familyasi=models.CharField(max_length=200)
    manzili = models.TextField()
    t_yili = models.DateField()
    tashxisi = models.TextField()


    def __str__(self):
        return self.ismi
    
# class shifokor(models.Model):
#     ismi = models.CharField(max_length=200)
#     familyasi=models.CharField(max_length=200)
#     t_yili = models.DateField()
#     lavozimi = models.CharField(max_length=200)
#     yunalishi = models.CharField(max_length=200)
#     def  __str__(self):
#           return self.ismi
      


    
#     def __str__(self):
#         return self.ismi