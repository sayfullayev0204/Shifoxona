from django.contrib import admin
from .models import bemor


class BemorAdmin(admin.ModelAdmin):
    search_fields = ['ismi']

admin.site.register(bemor, BemorAdmin)

