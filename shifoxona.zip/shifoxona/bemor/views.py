from .models import bemor
from django.shortcuts import render
from django.views.generic import ListView, DetailView
from django.db.models import Q

class BemorListView(ListView):
    model = bemor
    template_name = 'bemor_list.html'
    context_object_name = 'bemor' 
    
    def get_queryset(self):
        queryset = bemor.objects.all()
        q = self.request.GET.get('q')
        if q:
            queryset = queryset.filter(Q(ismi__contains=q))
        return queryset

class BemorDetailView(DetailView):
    model = bemor 
    template_name = 'bemor_detail.html'
    context_object_name = 'bemor' 
    
    def get(self, request, *args, **kwargs):
        print("BemorDetailView is called!")
        return super().get(request, *args, **kwargs)
