from django.apps import AppConfig


class BemorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bemor'
